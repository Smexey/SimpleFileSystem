#pragma once
#include "Part.h"
#include "synch.h"
#include "bitvect.h"
#include "KernFile.h"
#include <map>

typedef unsigned long EntryNum;
const unsigned long ClusterEntryNo = 2048 / 20;
const unsigned long ClusterDataNo = 2048;
const unsigned long ClusterRootNo = 512;
class FileControl
{
private:
    unsigned long writers;
    unsigned long readers;
    unsigned long waitWriters;
    unsigned long waitReaders;
    Sem writeSem;
    Sem readSem;
    char* fname;
    Entry* entry;
    ClusterNo dirPos;
    ClusterNo dirOff;
    FileControl(char mode, char*, Entry*,ClusterNo, BytesCnt);
    ~FileControl()
    {
        delete fname;
        delete entry;
    }
    friend class KernPart;
    friend class KernFile;
};


class KernPart {
private:
    Partition* part;

public:
	Sem myPartSem;
	Sem deleteSem;
	Sem bitVectSem;
	bool marked;
	map<string, FileControl> mapOpen;
	BitVector* bitVect;
	char rootCache[ClusterSize];

	KernPart(Partition* p);
	~KernPart();
    virtual int readCluster(ClusterNo, char* buffer);
    virtual ClusterNo getNumOfClusters() const;
    virtual int writeCluster(ClusterNo, const char* buffer);

    FileControl* doesExist(char* fname,char);
    KernFile* openFileFromList(char*, char);
    FileControl* makeNewFile(char* fname,char mode);
    void makeNewFileHelp( char*, char* , ClusterNo, ClusterNo );
    KernFile* openFile(char*, char);
    ClusterNo newClusterFS(char*, char* , ClusterNo, ClusterNo );
    
    void closeFile(char*);
    bool deleteFile(char*);
    bool formatAndUnmount();
    bool nameEq(Entry* , char* );
    bool freeEntry(Entry* );
    
    bool fileDoesExists(char* fname);
    char readRootDir();

    
    void freeCluster(ClusterNo);
    ClusterNo getNewEmpty();
    void saveandclose();
    char format();
    bool mark();
};
