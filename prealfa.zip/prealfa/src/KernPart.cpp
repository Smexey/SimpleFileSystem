#include "KernPart.h"

FileControl::FileControl(char mode,char * n,Entry* ent,ClusterNo pos, BytesCnt off)
{
    fname=new char[strlen(n)+1];
	strncpy(fname, n, strlen(n) + 1);
    readSem=CreateSemaphore(0,0,1,0);
    writeSem=CreateSemaphore(0,0,1000,0);
    entry=new Entry();
    strncpy(entry->name,ent->name,8);
    strncpy(entry->ext,ent->ext, 8);
    entry->size=ent->size;
    entry->indexCluster=ent->indexCluster;
    entry->reserved=ent->reserved;
    dirPos=pos;
    dirOff=off;
    writers=0;
    readers=0;
    if(mode=='r')
    {
        readers++;
    }
    if(mode=='w' || mode=='a')
    {
        writers++;
    }
    waitWriters=0;
    waitReaders=0;
}

KernPart::KernPart(Partition * part)
{
    this->part=part;
    myPartSem = CreateSemaphore(0, 1, 1000, 0);
    bitVect=new BitVector(part->getNumOfClusters(),this);
    part->readCluster(bitVect->getRootPosition(), rootCache);
    
    marked = false;
    deleteSem=CreateSemaphore(0,0,1,0);
    bitVectSem=CreateSemaphore(0,1,100,0);
    
}

char KernPart::format()
{
    bitVect->format();
    for(int i=0; i<ClusterSize;i++)
        rootCache[i]=0;
     marked=false;
    return 0;
}

bool KernPart::mark()
{
    if(marked) return false;
    marked=true;
    if(mapOpen.empty())
        return true;
    SignalAndWait(myPartSem,deleteSem);
    return true;
}

int KernPart::readCluster(ClusterNo n, char* buffer) { part->readCluster(n, buffer); }

ClusterNo KernPart::getNumOfClusters() const { return part->getNumOfClusters(); }

int KernPart::writeCluster(ClusterNo n, const char* buffer) { part->writeCluster(n, buffer); }

FileControl* KernPart::makeNewFile(char* fname,char mode)
{
    ClusterNo* rootB=(ClusterNo*)rootCache;
    Entry* clEnt;
    ClusterNo* clH;
    char rootBuf1[ClusterSize];
    char rootBuf2[ClusterSize];
    for(ClusterNo i=0; i<ClusterRootNo;i++)
        if(rootB[i]!=0)
        {
            readCluster(rootB[i], rootBuf1);
            if(i<ClusterRootNo/2)
            {
                clEnt=(Entry*)rootBuf1;
                for(ClusterNo j=0; j<ClusterEntryNo;j++)
                    if(freeEntry(clEnt+j))
                    {
                        makeNewFileHelp(fname, rootBuf1, rootB[i], j);
                        return new FileControl(mode,fname, clEnt+j,rootB[i],j);
                    }
            }
            else
            {
                clH=(ClusterNo*)rootBuf1;
                for(ClusterNo j=0; j<ClusterRootNo;j++)
                    if(clH[j]!=0)
                    {
                        readCluster(clH[j], rootBuf2);
                        clEnt=(Entry*)rootBuf2;
                        for(ClusterNo k=0; k<ClusterEntryNo;k++)
                            if(freeEntry(clEnt+k))
                            {
                                makeNewFileHelp(fname, rootBuf2, clH[i], j);
                                return new FileControl(mode,fname, clEnt+k,clH[j],k);
                            }
                    }
            }
        }
        else
        {
            ClusterNo clNo=newClusterFS(rootCache, rootBuf1, bitVect->getRootPosition(), i);
            if(i<ClusterRootNo/2)
            {
                clEnt=(Entry*)rootBuf1;
                makeNewFileHelp(fname, rootBuf1, clNo, 0);
                return new FileControl(mode,fname, clEnt,clNo,0);
            }
            else
            {
                ClusterNo clNo2=newClusterFS(rootBuf1, rootBuf2, clNo, 0);
                clEnt=(Entry*)rootBuf2;
                makeNewFileHelp(fname, rootBuf2, clNo2, 0);
                return new FileControl(mode,fname, clEnt,clNo2,0);
            }
        }
    return nullptr;
}
FileControl* KernPart::doesExist(char* fname,char mode)
{
    ClusterNo* rootB=(ClusterNo*)rootCache;
    Entry* clEnt;
    ClusterNo* clH;
    char rootBuf1[ClusterSize];
    char rootBuf2[ClusterSize];
    for(ClusterNo i=0; i<ClusterRootNo;i++)
        if(rootB[i]!=0)
        {
            readCluster(rootB[i], rootBuf1);
            if(i<ClusterRootNo/2)
            {
                clEnt=(Entry*)rootBuf1;
                for(ClusterNo j=0; j<ClusterEntryNo;j++)
                    if(nameEq(clEnt+j,fname))
                        return new FileControl(mode,fname, clEnt+j,rootB[i],j);
            }
            else
            {
                clH=(ClusterNo*)rootBuf1;
                for(ClusterNo j=0; j<ClusterRootNo;j++)
                    if(clH[j]!=0)
                    {
                        readCluster(clH[j], rootBuf2);
                        clEnt=(Entry*)rootBuf2;
                        for(ClusterNo k=0; k<ClusterEntryNo;k++)
                            if(nameEq(clEnt+k,fname))
                                return new FileControl(mode,fname, clEnt+k,clH[j],k);
                    }
            }
        }
    return nullptr;
}
KernFile* KernPart::openFile(char *fname, char mode)
{
    if (marked)
        return nullptr;
    KernFile* myFile=openFileFromList(fname,mode);
    if(myFile)
        return myFile;
    FileControl* myFileControl=doesExist(fname, mode);
    if(myFileControl)
    {
        mapOpen.insert(pair<char*, FileControl>(fname, myFileControl));
        myFile= new KernFile(myFileControl,this,mode);
        if(myFile)
            return myFile;
    }
    if(mode=='w')
    {
        FileControl* myFileControl=makeNewFile(fname, mode);
        if(myFileControl)
        {
			mapOpen.insert(pair<char*, FileControl>(fname, myFileControl));
            myFile= new KernFile(myFileControl,this,mode);
            if(myFile)
                return myFile;
        }
    }
    return nullptr;
}
    
void KernPart::closeFile(char *fname)
{
    string name=fname;
    // std::list<FileControl*>::iterator it;
    // for (it=listOpenFile->begin(); it != listOpenFile->end(); it++)
    //      if(it->second.fname==name)
    //          break;

    map<string, FileControl>::iterator it = mapOpen.find(fname);
    if(it->second.readers<2 && it->second.writers==0 && it->second.waitWriters==0)
    {
        mapOpen.erase(it);
        delete &it->second;
        // delete (*it);
        // (*it)=nullptr;
        // listOpenFile->erase(it);
        if(mapOpen.empty() && marked)
            signal(deleteSem);
        return;
    }
    if(it->second.readers>0)
    {
        it->second.readers--;
        if(it->second.readers==0)
            if(it->second.waitWriters>0)
            {
                it->second.waitWriters--;
                signal(it->second.writeSem);
            }
        return;
    }
    it->second.writers--;
    if(it->second.waitWriters>0)
    {
        it->second.waitWriters--;
        signal(it->second.writeSem);
    }
    else
        while(it->second.writers>0)
        {
            it->second.writers--;
            signal(it->second.readSem);
        }
}

bool KernPart::deleteFile(char* fname){
    map<string, FileControl>::iterator it = mapOpen.find(fname);
    // for (it=listOpenFile->begin(); it != listOpenFile->end(); it++)
    //     if(strcmp (it->second.fname,fname)==0)
    //         return false;
    FileControl* FileControl=doesExist(fname, 'd');
    if(!FileControl)
        return false;
    KernFile * myFile=new KernFile(FileControl,this,'d');
    delete myFile;
    wait(bitVectSem);
    bitVect->free(FileControl->entry->indexCluster);
    signal(bitVectSem);
    char buffer[ClusterSize];
    readCluster(FileControl->dirPos, buffer);
    for(ClusterNo i=FileControl->dirOff*20; i<FileControl->dirOff*20+8;i++)
        buffer[i]=0;
    writeCluster(FileControl->dirPos, buffer);
    delete FileControl;
    return true;
}

bool KernPart::nameEq(Entry* ent, char* fname)
{
    int  k = 3;
    bool help=false;
    for (int i = 0; i < FNAMELEN; i++)
    {
        if (i+k == strlen(fname) || fname[i+k] == '.')
        {
            help = true;
            k=i+k+1;
        }
        if(!help && ent->name[i] != fname[i+k])
            return false;
        if(help && ent->name[i]!=' ')
            return false;
    }
    help=false;
    for (int i = 0; i < FEXTLEN; i++)
    {
        if (i+k >= strlen(fname))
            help = true;
        if(!help && ent->ext[i] != fname[i+k])
            return false;
        if(help && ent->ext[i]!=' ')
            return false;
    }
    return true;
}

bool KernPart::freeEntry(Entry* ent)
{
    for (int i = 0; i < FNAMELEN; i++)
        if (ent->name[i]!=0)
            return false;
    return true;
}

void KernPart::makeNewFileHelp( char* fname, char* buffer, ClusterNo pos, ClusterNo off)
{
    int  k = 3;
    bool help=false;
    Entry* entry=(Entry*)buffer;
    for (int i = 0; i < FNAMELEN; i++)
    {
        if (i+k == strlen(fname) || fname[i+k] == '.')
        {
            help = true;
            k=i+k+1;
        }
        if(!help)
            entry[off].name[i]=fname[k+i];
        if(help)
            entry[off].name[i]=' ';
    }
    help=false;
    for (int i = 0; i < FEXTLEN; i++)
        if (i+k >= strlen(fname))
            entry[off].ext[i]=' ';
        else
            entry[off].ext[i]=fname[k+i];
    wait(bitVectSem);
    entry[off].indexCluster=bitVect->getFirstEmpty();
    signal(bitVectSem);
    entry[off].size=0;
    writeCluster(pos, buffer);
}

ClusterNo KernPart::newClusterFS(char* bufferRoot, char* buffer, ClusterNo pos, ClusterNo off)
{
    wait(bitVectSem);
    ClusterNo k=bitVect->getFirstEmpty();
    signal(bitVectSem);
    ((ClusterNo*) bufferRoot)[off]=k;
    writeCluster(pos, bufferRoot);
    for(ClusterNo i=0; i<ClusterSize; i++)
        buffer[i]=0;
    return k;
}

bool KernPart::fileDoesExists(char* fname)
{
    FileControl* el=doesExist(fname,'x');
    if(el)
    {
        delete el;
        return true;
    }
    return false;
}

char KernPart::readRootDir()
{
    ClusterNo* rootB=(ClusterNo*)rootCache;
    Entry* clEnt;
    ClusterNo* clH;
    char rootBuf1[ClusterSize];
    char rootBuf2[ClusterSize];
    EntryNum cnt=0;
    // EntryNum end=n+64;
    for(ClusterNo i=0; i<ClusterRootNo;i++)
        if(rootB[i]!=0)
        {
            readCluster(rootB[i], rootBuf1);
            if(i<ClusterRootNo/2)
            {
                clEnt=(Entry*)rootBuf1;
                for(ClusterNo j=0; j<ClusterEntryNo;j++)
                    if(!freeEntry(clEnt+j))
                    {
                        cnt++;
                        // if(cnt>=n)
                        // {
                        //     for(int p=0; p<FNAMELEN; p++)
                        //         d[cnt-n].name[p]=clEnt[j].name[p];
                        //     for(int p=0; p<FEXTLEN; p++)
                        //         d[cnt-n].ext[p]=clEnt[j].ext[p];
                        //     d[cnt-n].size=clEnt[j].size;
                        //     d[cnt-n].indexCluster=clEnt[j].indexCluster;
                        // }
                        // cnt++;
                        // if(cnt==end)
                        //     return 64;
                    }
            }
            else
            {
                clH=(ClusterNo*)rootBuf1;
                for(ClusterNo j=0; j<ClusterRootNo;j++)
                    if(clH[j]!=0)
                    {
                        readCluster(clH[j], rootBuf2);
                        clEnt=(Entry*)rootBuf2;
                        for(ClusterNo k=0; k<ClusterEntryNo;k++)
                            if(!freeEntry(clEnt+k))
                            {
                                cnt++;
                                // if(cnt>=n)
                                // {
                                //     for(int p=0; p<FNAMELEN; p++)
                                //         d[cnt-n].name[p]=clEnt[k].name[p];
                                //     for(int p=0; p<FEXTLEN; p++)
                                //         d[cnt-n].ext[p]=clEnt[k].ext[p];
                                //     d[cnt-n].size=clEnt[k].size;
                                //     d[cnt-n].indexCluster=clEnt[k].indexCluster;
                                // }
                                // cnt++;
                                // if(cnt==end)
                                //     return 64;
                            }
                    }
            }
        }
    return cnt;
}
// void KernPart::saveandclose() {}
// ClusterNo KernPart::getNewEmpty() {}
// void KernPart::freeCluster(ClusterNo) {}
