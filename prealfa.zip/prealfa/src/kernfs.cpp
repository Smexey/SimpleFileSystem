#include "kernfs.h"

KernFS::KernFS() {
    InitializeCriticalSection(&cs);
    mountedsem = CreateSemaphore(NULL, 1, 1, NULL);  // samo jedan montira
}

KernFS::~KernFS() { unmount(); }

char KernFS::mount(Partition *partition) {
    if (partition == 0) {
        return 0;
    }
    wait(mountedsem);

    CriticalSectionLock lck(cs);

    kernpart = new KernPart(partition);
    return 0;
}

char KernFS::unmount() {
    if (kernpart == nullptr) return 0;

    // synch
    CriticalSectionLock lck(cs);
    kernpart->saveandclose();
	if (kernpart->mark()) return 0;
    signal(mountedsem);
    delete kernpart;
    kernpart = nullptr;
    return 0;
}

char KernFS::format() {
    if (kernpart == nullptr) return 0;

	wait(kernpart->myPartSem);
	kernpart->format();
	signal(kernpart->myPartSem);
	return 1;
}

FileCnt KernFS::readRootDir() {

    if (kernpart == nullptr) return 0;
	wait(kernpart->myPartSem);
	FileCnt v = kernpart->readRootDir();
	signal(kernpart->myPartSem);
	return v;
}

char KernFS::doesExist(char *fname) {
    if (kernpart == nullptr) return 0;
	wait(kernpart->myPartSem);
	if (kernpart->doesExist(fname)) {
		signal(kernpart->myPartSem);
		return 1;
	}
	signal(kernpart->myPartSem);
	return 0;
}

File *KernFS::open(char *fname, char mode) { 
	if (!kernpart)
		return 0;
	wait(kernpart->myPartSem);
	KernFile* kerf = kernpart->openFile(fname, mode);
	if (kerf)
	{
		File* f = new File();
		f->myImpl = kerf;
		signal(kernpart->myPartSem);
		return f;
	}
	signal(kernpart->myPartSem);
	return nullptr;

}
char KernFS::deleteFile(char *fname) {
    if (kernpart == nullptr) return 0;

	wait(kernpart->myPartSem);
	if (!kernpart->deleteFile(fname)) {
		signal(kernpart->myPartSem);
		return 0;
	}
	signal(kernpart->myPartSem);
	return 1;
}
